#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
  echo "Java 17+ is required. Install a JDK and Android SDK first." >&2
  exit 1
fi
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is not installed. Open this folder in Android Studio, or install Gradle." >&2
  echo "A GitHub Actions workflow is included to build a debug APK in the cloud." >&2
  exit 1
fi
gradle --no-daemon assembleDebug
printf '\nAPK output: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
