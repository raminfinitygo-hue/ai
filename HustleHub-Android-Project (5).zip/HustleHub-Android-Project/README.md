# HustleHub AI — Android WebView wrapper

This project packages `app/src/main/assets/index.html` in a small Android WebView shell. It is a **debug/test build project**, not a store-approved release.

## Build a debug APK locally

Requirements: JDK 17, Android SDK Platform 35 and Build Tools, Gradle 8.11+ (or open in a compatible Android Studio release).

```bash
./build-apk.sh
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

You can also open this folder in Android Studio and run **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Build in GitHub Actions

Push this project to a GitHub repository, open **Actions > Build HustleHub APK > Run workflow**, then download the `HustleHub-AI-debug-apk` artifact from the completed run.

## Before production or store submission

- The embedded HTML currently sends live AI requests directly from the client when an API key is configured. Do **not** ship a production API key in the APK or browser storage. Move AI calls to a secure backend with server-side secrets, auth, rate limits, and abuse controls.
- Test all screens and interactions on real Android devices, accessibility settings, different screen sizes, slow/offline network, and API failures.
- Implement a real support/report endpoint; the current HTML's report action only copies report details for the user to send.
- Complete privacy policy, data-safety disclosures, content rating, store listing, signing, and current store-specific review requirements.
- Google Play generally expects an Android App Bundle (AAB) for new app submissions; a debug APK is for testing, not publishing.

The project has not been built or runtime-tested in this environment because an Android SDK/Gradle installation is not available here. Do not represent it as a verified, bug-free, or store-approved app.
